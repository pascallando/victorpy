from distutils.core import setup

setup(
    name = 'victorpy',
    packages = ['victorpy'],
    version = 'v0.1',
    description = 'A simple yet powerful static site generator with Python sugar',
    author = 'Pascal LANDO',
    author_email = 'pascal.lando@u-picardie.fr',
    url = '',
    download_url = '',
    keywords = ['static site', 'python'],
    classifiers = [],
)