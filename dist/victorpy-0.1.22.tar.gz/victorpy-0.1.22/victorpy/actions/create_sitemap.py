def main(site, logging):

    logging.info("Creating sitemap...")

    # TODO
